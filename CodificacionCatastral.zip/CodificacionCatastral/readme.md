# Codificación Catastral en Espiral

Este plugin para QGIS permite codificar automáticamente predios dentro de polígonos catastrales siguiendo un patrón de espiral en sentido horario, comenzando desde el predio ubicado más al noroeste.

## Características

- Asigna códigos a predios en un patrón espiral hacia adentro en sentido horario
- Reinicia la numeración para cada polígono catastral
- Usa el centroide del predio para determinar a qué polígono pertenece
- Permite seleccionar campos de identificador único para las capas
- Crea tanto un campo para el código completo como otro solo para el número de predio

## Instalación

### Método 1: Desde el ZIP

1. Descarga el archivo ZIP del plugin
2. En QGIS, ve a "Complementos" > "Administrar e instalar complementos"
3. Selecciona "Instalar a partir de ZIP"
4. Navega hasta el archivo ZIP descargado y selecciónalo
5. Haz clic en "Instalar complemento"

### Método 2: Manual

1. Descarga o clona este repositorio
2. Copia la carpeta "codificacion_catastral" a la carpeta de plugins de QGIS:
   - En Windows: `C:\Users\{username}\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins`
   - En Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins`
   - En macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins`
3. Reinicia QGIS
4. Activa el plugin en "Complementos" > "Administrar e instalar complementos" > "Instalados"

## Uso

1. En QGIS, haz clic en el icono del plugin o ve a "Complementos" > "Codificación Catastral" > "Codificación Catastral en Espiral"
2. En el diálogo que aparece:
   - Selecciona la capa de polígonos catastrales y su campo identificador
   - Selecciona la capa de predios y su campo identificador
   - Define los nombres para los campos de salida
3. Haz clic en "OK" para ejecutar el proceso

## Requisitos

- QGIS 3.0 o superior
- Capas de polígonos catastrales y predios cargadas en el proyecto

## Soporte

Si tienes problemas o sugerencias, puedes:
- Crear un issue en el repositorio
- Contactar al autor por correo electrónico
