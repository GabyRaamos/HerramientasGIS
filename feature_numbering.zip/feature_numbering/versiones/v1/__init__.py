def classFactory(iface):
    """Método para cargar la versión 1 del plugin"""
    from .versiones.v1.plugin import FeatureNumbering
    return FeatureNumbering(iface)