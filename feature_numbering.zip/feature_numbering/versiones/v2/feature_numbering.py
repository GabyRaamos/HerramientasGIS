from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.core import (QgsMapLayer, QgsField, QgsVectorDataProvider, 
                       QgsSymbol, QgsFillSymbol, QgsRendererCategory, 
                       QgsCategorizedSymbolRenderer, Qgis,
                       QgsSingleSymbolRenderer)
from PyQt5.QtCore import QVariant, Qt
from qgis.gui import QgsMapToolIdentifyFeature
import os.path

class FeatureNumberingTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.layer = None
        self.selection_numbers = {}
        self.last_number = 0
        self.double_click_timer = 0
        self.double_click_threshold = 300  # milliseconds
        
    def canvasReleaseEvent(self, event):
        # Implementar lógica de doble clic
        current_time = event.time()
        
        if not self.layer or not self.layer.isEditable():
            return
            
        result = self.identify(event.x(), event.y(), [self.layer])
        if not result:
            return
            
        feature = result[0].mFeature
        fid = feature.id()
        
        # Preparar el índice del campo de selección
        field_index = self.layer.fields().indexFromName("SelectionO")
        if field_index == -1:
            provider = self.layer.dataProvider()
            field = QgsField("SelectionO", QVariant.Int)
            provider.addAttributes([field])
            self.layer.updateFields()
            field_index = self.layer.fields().indexFromName("SelectionO")
        
        # Verificar si es un doble clic para resetear
        if (current_time - self.double_click_timer) < self.double_click_threshold:
            # Es un doble clic: resetear numeración de este polígono
            if fid in self.selection_numbers:
                del self.selection_numbers[fid]
                feature.setAttribute(field_index, None)
                self.layer.updateFeature(feature)
                self.layer.commitChanges()
                
                # Volver a aplicar el renderizador para actualizar la visualización
                self._apply_categorized_renderer()
                
                # Mostrar mensaje de confirmación
                self.iface.messageBar().pushMessage(
                    "Renumeración", 
                    "Polígono deseleccionado.", 
                    level=Qgis.Info
                )
                
                # Iniciar edición nuevamente
                self.layer.startEditing()
                
                return
        
        # Lógica de numeración normal
        if fid not in self.selection_numbers:
            self.last_number += 1
            self.selection_numbers[fid] = self.last_number
            feature.setAttribute(field_index, self.last_number)
            self.layer.updateFeature(feature)
            self.layer.commitChanges()
            
            # Aplicar renderizador categorizado
            self._apply_categorized_renderer()
            
            # Iniciar edición nuevamente
            self.layer.startEditing()
        
        # Actualizar tiempo de último clic
        self.double_click_timer = current_time
        
    def _apply_categorized_renderer(self):
        """Aplicar un renderizador categorizado para resaltar características numeradas."""
        if not self.layer:
            return
        
        # Crear categorías
        categories = []
        
        # Categoría para características sin numerar (gris)
        symbol_unnumbered = QgsFillSymbol.createSimple({
            'color': '200,200,200,100',
            'outline_color': '0,0,0,255',
            'outline_width': '0.5'
        })
        cat_unnumbered = QgsRendererCategory(None, symbol_unnumbered, 'Sin Numerar')
        categories.append(cat_unnumbered)
        
        # Categoría para características numeradas (verde)
        symbol_numbered = QgsFillSymbol.createSimple({
            'color': '0,255,0,100',
            'outline_color': '0,0,0,255',
            'outline_width': '0.5'
        })
        cat_numbered = QgsRendererCategory(1, symbol_numbered, 'Numerado')
        categories.append(cat_numbered)
        
        # Crear renderizador categorizado
        renderer = QgsCategorizedSymbolRenderer('SelectionO', categories)
        self.layer.setRenderer(renderer)
        
        # Actualizar el lienzo
        self.layer.triggerRepaint()
        self.canvas.refreshAllLayers()
        
    def setLayer(self, layer):
        self.layer = layer
        self.selection_numbers = {}
        self.last_number = 0
        
        # Restablecer renderizador al configurar una nueva capa
        if layer:
            # Verificar y manejar diferentes tipos de renderizadores
            try:
                # Intentar cambiar el método de clasificación si es posible
                current_renderer = layer.renderer()
                if hasattr(current_renderer, 'setClassificationMethod'):
                    current_renderer.setClassificationMethod(None)
            except Exception:
                # Si falla, simplemente ignorar
                pass
            
            layer.triggerRepaint()

class FeatureNumbering:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = 'Feature Numbering V2'
        self.toolbar = self.iface.addToolBar('Feature Numbering V2')
        self.toolbar.setObjectName('FeatureNumberingV2')
        self.tool = None
    
    def initGui(self):
        # Obtener ruta del ícono 
        icon_path = os.path.join(os.path.dirname(__file__), '..', '..', 'recursos', 'icon_v2.png')
        icon = QIcon(icon_path)
        
        # Crear acción para numerar características
        self.action_number = QAction(
            icon,
            'Numerar Features (V2)',
            self.iface.mainWindow())
        self.action_number.setCheckable(True)
        self.action_number.triggered.connect(self.run)
        
        # Agregar a la barra de herramientas y menú
        self.iface.addToolBarIcon(self.action_number)
        self.iface.addPluginToMenu(self.menu, self.action_number)
        
        # Crear la herramienta de mapa
        self.tool = FeatureNumberingTool(self.iface.mapCanvas(), self.iface)
    
    def unload(self):
        # Eliminar complemento de la interfaz de usuario
        self.iface.removePluginMenu(self.menu, self.action_number)
        self.iface.removeToolBarIcon(self.action_number)
        if self.toolbar:
            self.toolbar.deleteLater()
    
    def run(self):
        if self.action_number.isChecked():
            layer = self.iface.activeLayer()
            if layer and layer.type() == QgsMapLayer.VectorLayer:
                # Asegurar que la capa esté en modo edición
                if not layer.isEditable():
                    layer.startEditing()
                
                # Configurar la herramienta de numeración
                self.tool.setLayer(layer)
                self.iface.mapCanvas().setMapTool(self.tool)
            else:
                self.action_number.setChecked(False)
        else:
            # Desactivar la herramienta de mapa si la acción está desactivada
            self.iface.mapCanvas().unsetMapTool(self.tool)

def classFactory(iface):
    return FeatureNumbering(iface)
