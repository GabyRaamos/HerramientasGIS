def classFactory(iface):
    """Método para cargar la versión actual del plugin"""
    from .versiones.v2.plugin import FeatureNumbering
    return FeatureNumbering(iface)