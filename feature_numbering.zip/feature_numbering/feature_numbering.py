from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsMapLayer, QgsField, QgsVectorDataProvider
from PyQt5.QtCore import QVariant
from qgis.gui import QgsMapToolIdentifyFeature
import os.path

class FeatureNumberingTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = None
        self.selection_numbers = {}
        self.last_number = 0
        
    def canvasReleaseEvent(self, event):
        if not self.layer or not self.layer.isEditable():
            return
            
        result = self.identify(event.x(), event.y(), [self.layer])
        if not result:
            return
            
        feature = result[0].mFeature
        fid = feature.id()
        
        field_index = self.layer.fields().indexFromName("SelectionO")
        if field_index == -1:
            provider = self.layer.dataProvider()
            field = QgsField("SelectionO", QVariant.Int)
            provider.addAttributes([field])
            self.layer.updateFields()
            field_index = self.layer.fields().indexFromName("SelectionO")
        
        if fid not in self.selection_numbers:
            self.last_number += 1
            self.selection_numbers[fid] = self.last_number
            feature.setAttribute(field_index, self.last_number)
            self.layer.updateFeature(feature)
            self.layer.commitChanges()
            self.layer.startEditing()
            
    def setLayer(self, layer):
        self.layer = layer
        self.selection_numbers = {}
        self.last_number = 0

class FeatureNumbering:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = 'Feature Numbering'
        self.toolbar = self.iface.addToolBar('Feature Numbering')
        self.toolbar.setObjectName('FeatureNumbering')
        self.tool = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path)
        
        self.action_number = QAction(
            icon,
            'Numerar Features',
            self.iface.mainWindow())
        self.action_number.setCheckable(True)
        self.action_number.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action_number)
        self.iface.addPluginToMenu(self.menu, self.action_number)
        
        self.tool = FeatureNumberingTool(self.iface.mapCanvas())

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action_number)
        self.iface.removeToolBarIcon(self.action_number)
        if self.toolbar:
            self.toolbar.deleteLater()

    def run(self):
        if self.action_number.isChecked():
            layer = self.iface.activeLayer()
            if layer and layer.type() == QgsMapLayer.VectorLayer:
                if not layer.isEditable():
                    layer.startEditing()
                self.tool.setLayer(layer)
                self.iface.mapCanvas().setMapTool(self.tool)
            else:
                self.action_number.setChecked(False)
        else:
            self.iface.mapCanvas().unsetMapTool(self.tool)