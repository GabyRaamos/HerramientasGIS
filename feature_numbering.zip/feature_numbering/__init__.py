def classFactory(iface):
    from .feature_numbering import FeatureNumbering
    return FeatureNumbering(iface)