from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.core import (QgsMapLayer, QgsField, QgsVectorDataProvider, 
                      QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer,
                      QgsFillSymbol)
from PyQt5.QtCore import QVariant
from qgis.gui import QgsMapToolIdentifyFeature
import os.path

class FeatureNumberingTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = None
        self.selection_numbers = {}
        self.last_number = 0
        self.original_renderer = None
        
    def canvasReleaseEvent(self, event):
        if not self.layer or not self.layer.isEditable():
            return
            
        result = self.identify(event.x(), event.y(), [self.layer])
        if not result:
            return
            
        feature = result[0].mFeature
        fid = feature.id()
        
        field_index = self.layer.fields().indexFromName("SelectionO")
        if field_index == -1:
            provider = self.layer.dataProvider()
            field = QgsField("SelectionO", QVariant.Int)
            provider.addAttributes([field])
            self.layer.updateFields()
            field_index = layer.fields().indexFromName("SelectionO")
        
        if fid not in self.selection_numbers:
            self.last_number += 1
            self.selection_numbers[fid] = self.last_number
            feature.setAttribute(field_index, self.last_number)
            self.layer.updateFeature(feature)
            self.layer.commitChanges()
            self.layer.startEditing()
            
            # Actualizar el renderizado después de numerar
            self.update_renderer()
            
    def setLayer(self, layer):
        self.layer = layer
        self.selection_numbers = {}
        self.last_number = 0
        # Guardar el renderizador original
        self.original_renderer = layer.renderer().clone()
        # Configurar el renderizado inicial
        self.setup_renderer()
        
    def setup_renderer(self):
        if not self.layer:
            return
            
        # Crear categorías para polígonos numerados y no numerados
        categories = []
        
                # Símbolo para polígonos numerados (resaltado)
        numbered_symbol = QgsFillSymbol.createSimple({
            'color': '255,165,0,50',  # Naranja semitransparente
            'color_border': 'red',
            'width_border': '0.6'
        })
        numbered_cat = QgsRendererCategory('numbered', numbered_symbol, 'Numerado')
        categories.append(numbered_cat)
        
        # Símbolo para polígonos no numerados (normal)
        normal_symbol = QgsFillSymbol.createSimple({
            'color': 'yellow',
            'color_border': 'black'
        })
        normal_cat = QgsRendererCategory(None, normal_symbol, 'No numerado')
        categories.append(normal_cat)
        
        # Crear y aplicar el renderizador categorizado
        renderer = QgsCategorizedSymbolRenderer('SelectionO', categories)
        self.layer.setRenderer(renderer)
        self.layer.triggerRepaint()
        
    def update_renderer(self):
        self.layer.triggerRepaint()
        
    def deactivate(self):
        # Restaurar el renderizador original cuando se desactiva la herramienta
        if self.layer and self.original_renderer:
            self.layer.setRenderer(self.original_renderer)
            self.layer.triggerRepaint()
        super().deactivate()

class NumeracionFeature:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = 'Numeracion Feature'
        self.toolbar = self.iface.addToolBar('Numeracion Feature')
        self.toolbar.setObjectName('NumeracionFeature')
        self.tool = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path)
        
        self.action_number = QAction(
            icon,
            'Numerar Features',
            self.iface.mainWindow())
        self.action_number.setCheckable(True)
        self.action_number.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action_number)
        self.iface.addPluginToMenu(self.menu, self.action_number)
        
        self.tool = FeatureNumberingTool(self.iface.mapCanvas())

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action_number)
        self.iface.removeToolBarIcon(self.action_number)
        if self.toolbar:
            self.toolbar.deleteLater()

    def run(self):
        if self.action_number.isChecked():
            layer = self.iface.activeLayer()
            if layer and layer.type() == QgsMapLayer.VectorLayer:
                if not layer.isEditable():
                    layer.startEditing()
                self.tool.setLayer(layer)
                self.iface.mapCanvas().setMapTool(self.tool)
            else:
                self.action_number.setChecked(False)
        else:
            self.tool.deactivate()
            self.iface.mapCanvas().unsetMapTool(self.tool)