def classFactory(iface):
    from .numeracion_feature import NumeracionFeature
    return NumeracionFeature(iface)