from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsMapLayer, QgsField, QgsVectorDataProvider
from PyQt5.QtCore import QVariant
from qgis.gui import QgsMapToolIdentifyFeature
import os.path

class FeatureNumberingTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = None
        self.selection_numbers = {}
        self.last_number = 0
        self.start_number = 1
        
    def ensure_field_exists(self):
        """Asegura que existe el campo SelectionO, si no, lo crea"""
        if not self.layer:
            return False
            
        field_index = self.layer.fields().indexFromName("SelectionO")
        if field_index == -1:
            provider = self.layer.dataProvider()
            if provider.capabilities() & QgsVectorDataProvider.AddAttributes:
                field = QgsField("SelectionO", QVariant.Int)
                if provider.addAttributes([field]):
                    self.layer.updateFields()
                    QMessageBox.information(None, "Campo creado", 
                        "Se ha creado el campo 'SelectionO' para almacenar la numeración.")
                    return True
                else:
                    QMessageBox.warning(None, "Error", 
                        "No se pudo crear el campo 'SelectionO'.")
                    return False
            else:
                QMessageBox.warning(None, "Error", 
                    "La capa no permite añadir campos.")
                return False
        return True
            
    def canvasReleaseEvent(self, event):
        if not self.layer or not self.layer.isEditable():
            return
            
        result = self.identify(event.x(), event.y(), [self.layer])
        if not result:
            return
            
        feature = result[0].mFeature
        fid = feature.id()
        
        field_index = self.layer.fields().indexFromName("SelectionO")
        if field_index == -1:
            if not self.ensure_field_exists():
                return
            field_index = self.layer.fields().indexFromName("SelectionO")
        
        if fid not in self.selection_numbers:
            current_number = self.last_number + 1
            self.selection_numbers[fid] = current_number
            feature.setAttribute(field_index, current_number)
            self.layer.updateFeature(feature)
            self.layer.commitChanges()
            self.layer.startEditing()
            self.last_number = current_number
            
    def setLayer(self, layer):
        self.layer = layer
        self.selection_numbers = {}
        
        # Verificar y crear el campo si es necesario
        if not self.ensure_field_exists():
            return
        
        # Preguntar por el número inicial
        number, ok = QInputDialog.getInt(
            None, 
            "Número Inicial", 
            "Ingrese el número inicial para la numeración:",
            value=1,
            min=1,
            max=999999
        )
        
        if ok:
            self.start_number = number
            self.last_number = number - 1
        else:
            self.start_number = 1
            self.last_number = 0

    def deactivate(self):
        super().deactivate()
        
class NumeracionFeature:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = 'Numeracion Feature'
        self.toolbar = self.iface.addToolBar('Numeracion Feature')
        self.toolbar.setObjectName('NumeracionFeature')
        self.tool = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        icon = QIcon(icon_path)
        
        self.action_number = QAction(
            icon,
            'Numerar Features',
            self.iface.mainWindow())
        self.action_number.setCheckable(True)
        self.action_number.triggered.connect(self.run)
        
        self.iface.addToolBarIcon(self.action_number)
        self.iface.addPluginToMenu(self.menu, self.action_number)
        
        self.tool = FeatureNumberingTool(self.iface.mapCanvas())

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action_number)
        self.iface.removeToolBarIcon(self.action_number)
        if self.toolbar:
            self.toolbar.deleteLater()

    def run(self):
        if self.action_number.isChecked():
            layer = self.iface.activeLayer()
            if layer and layer.type() == QgsMapLayer.VectorLayer:
                if not layer.isEditable():
                    layer.startEditing()
                self.tool.setLayer(layer)
                self.iface.mapCanvas().setMapTool(self.tool)
            else:
                self.action_number.setChecked(False)
        else:
            self.tool.deactivate()
            self.iface.mapCanvas().unsetMapTool(self.tool)